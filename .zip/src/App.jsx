import "./App.css";
import Header from "./components/Header.jsx";
import Catalog from "./components/Catalog.jsx";

export default function App() {
  return (
    <>
      <Header />
      <main className="page-content">
        <Catalog />
      </main>
    </>
  );
}