import GameCard from "./GameCard.jsx";

const games = [
  {
    id: 1,
    title: "Portal 2",
    description: "Головоломки з порталами.",
  },
  {
    id: 2,
    title: "Terraria",
    description: "Дослідження та будівництво.",
  },
  {
    id: 3,
    title: "Stardew Valley",
    description: "Розвиток власної ферми.",
  },
];

export default function Catalog() {
  return (
    <section aria-labelledby="catalog-title">
      <h2 id="catalog-title">Каталог ігор</h2>
      <div className="game-grid">
        {games.map((game) => (
          <GameCard
            key={game.id}
            title={game.title}
            description={game.description}
          />
        ))}
      </div>
    </section>
  );
}