import { useState } from "react";

export default function GameCard({ title, description }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <article className="game-card">
      <h3>{title}</h3>
      <button
        type="button"
        aria-expanded={isOpen}
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? "Приховати опис" : "Показати опис"}
      </button>
      {isOpen && <p className="game-description">{description}</p>}
    </article>
  );
}